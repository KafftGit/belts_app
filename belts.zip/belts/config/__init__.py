"""Project configuration package."""
